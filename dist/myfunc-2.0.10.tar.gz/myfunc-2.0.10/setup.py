from setuptools import setup, find_packages

setup(
    name="myfunc",
    version="2.0.10",
    packages=find_packages(),
)
