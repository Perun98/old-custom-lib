from setuptools import setup, find_packages

setup(
    name="myfunc",
    version="2.0.3e",
    packages=find_packages(),
)
