work_vars = {
    "keys" : {
        "openai_key": "sk-1234567890abcdef1234567890abcdef",
        "openai_key2": "sk-1234567890abcdef1234567890abcdef",
        "openai_key3": "sk-1234567890abcdef1234567890abcdef",
        },

    "names" : {
        "openai_model": "gpt-4o",
        },

    "addresses" : {
        "openai_address": "https://api.openai.com/v1/engines/gpt-4-turbo/completions",
        },
    }
