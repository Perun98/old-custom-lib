from setuptools import setup, find_packages

setup(
    name="myfunc",
    version="2.0.6a",
    packages=find_packages(),
)
