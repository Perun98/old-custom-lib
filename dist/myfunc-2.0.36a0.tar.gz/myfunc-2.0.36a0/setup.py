from setuptools import setup, find_packages

setup(
    name="myfunc",
    version="2.0.36a",
    packages=find_packages(),
)
