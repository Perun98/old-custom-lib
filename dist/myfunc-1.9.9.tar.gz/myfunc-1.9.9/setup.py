from setuptools import setup, find_packages

setup(
    name="myfunc",
    version="1.9.9",
    packages=find_packages(),
)
